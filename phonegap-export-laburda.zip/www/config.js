define( function ( require ) {

	"use strict";

	return {
		app_slug : 'laburda',
		wp_ws_url : 'https://appslaburda.com/wptomob-api/laburda',
		wp_url : 'https://appslaburda.com',
		theme : '0',
		version : '1.0',
		app_title : '',
		app_platform : 'android',
		gmt_offset : 0,
		debug_mode : 'off',
		auth_key : '>Z?)!;,SSIc74Z+H+`0 .+-^HQ6eX{1-MdK? H W}/v%gQ7h@M/SIce_zn>|:Ys_',
		options : {"refresh_interval":0},
		theme_settings : [],
		wptm_app_admob_interstitial : '',
		wptm_app_admob_banner : '',
		wptm_app_admob_rewardvideo: '',
		addons : []
	};

});
